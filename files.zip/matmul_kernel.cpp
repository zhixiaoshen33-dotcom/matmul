/**
 * matmul_kernel.cpp
 *
 * AscendC kernel: C(M×N, fp32) = A(M×K, fp16) × B(K×N, fp16)
 *
 * 修复点：
 *  1. 加入 using namespace fa_base_matmul（解决 MMParam 找不到的问题）
 *  2. 在 Init() 中正确调用 pipe.InitBuffer() 分配 LocalTensor 内存
 *  3. 矩阵尺寸统一使用 16 的整数倍（由 main.cpp 保证）
 *  4. kernel 入口改为 __global__ __aicore__ 函数，符合 AscendC 规范
 */

#include "kernel_operator.h"
#include "matmul.h"

using namespace AscendC;
using namespace fa_base_matmul;   // 修复：引入 MMParam 所在命名空间

// tile 大小常量（必须为 16 的整数倍，且与 MatmulFull 模板参数一致）
constexpr int BASE_M = 16;
constexpr int BASE_N = 16;
constexpr int BASE_K = 16;

class KernelMatmul {
public:
    __aicore__ inline void Init(
        GM_ADDR a, GM_ADDR b, GM_ADDR c,
        int m, int n, int k)
    {
        M = m; N = n; K = k;

        // 绑定全局内存
        A_gm.SetGlobalBuffer((__gm__ half*)a, M * K);
        B_gm.SetGlobalBuffer((__gm__ half*)b, K * N);
        C_gm.SetGlobalBuffer((__gm__ float*)c, M * N);

        // 修复：显式分配 L1 缓冲区（必须在调用 MatmulFull 前完成）
        pipe.InitBuffer(aL1Buf, M * K * sizeof(half));
        pipe.InitBuffer(bL1Buf, K * N * sizeof(half));
    }

    __aicore__ inline void Process()
    {
        // 从 GM 搬运到 L1
        LocalTensor<half> aL1 = aL1Buf.Get<half>();
        LocalTensor<half> bL1 = bL1Buf.Get<half>();

        DataCopy(aL1, A_gm, M * K);
        DataCopy(bL1, B_gm, K * N);

        // 设置 MatmulFull 参数
        MMParam mmParam;
        mmParam.m = M;
        mmParam.n = N;
        mmParam.k = K;
        mmParam.transA = false;
        mmParam.transB = false;

        // 分配 L0C 输出缓冲区
        pipe.InitBuffer(cL0CBuf, M * N * sizeof(float));
        LocalTensor<float> cL0C = cL0CBuf.Get<float>();

        // 调用 MatmulFull，模板参数：inputA类型, inputB类型, output类型, baseM, baseN, baseK, A布局, B布局
        MatmulFull<half, half, float,
                   BASE_M, BASE_N, BASE_K,
                   ABLayout::MK, ABLayout::KN>(
            aL1, bL1, cL0C, mmParam);

        // 将结果从 L0C 搬回 GM
        DataCopy(C_gm, cL0C, M * N);
    }

private:
    TPipe pipe;

    // 全局内存描述符
    GlobalTensor<half>  A_gm;
    GlobalTensor<half>  B_gm;
    GlobalTensor<float> C_gm;

    // L1/L0C 本地缓冲区
    TBuf<TPosition::A1>  aL1Buf;
    TBuf<TPosition::B1>  bL1Buf;
    TBuf<TPosition::CO1> cL0CBuf;

    int M, N, K;
};

// kernel 入口函数（host 通过 ACL 调用）
extern "C" __global__ __aicore__ void matmul_kernel(
    GM_ADDR a, GM_ADDR b, GM_ADDR c,
    int m, int n, int k)
{
    KernelMatmul op;
    op.Init(a, b, c, m, n, k);
    op.Process();
}

/**
 * host 侧调用的包装函数
 * 注意：host 端调用 AscendC kernel 需要通过 aclrtLaunchKernel 或
 *       bisheng 编译后的 .o 中导出符号；此处提供直接调用的 stub。
 */
extern "C" void matmul_kernel_do(
    void* d_A, void* d_B, void* d_C,
    int M, int N, int K)
{
    matmul_kernel<<<1, nullptr, nullptr>>>(
        (GM_ADDR)d_A,
        (GM_ADDR)d_B,
        (GM_ADDR)d_C,
        M, N, K);
}
