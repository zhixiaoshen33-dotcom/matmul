#!/bin/bash
# run.sh — 一键构建并运行 matmul_demo
#
# 使用方法：
#   chmod +x run.sh
#   ./run.sh
#
# 可选环境变量：
#   ASCEND_PATH   默认 /usr/local/Ascend
#   CANN_VERSION  默认 cann-8.5.0
#   DEVICE_ID     默认 0

set -e

# -------------------------------------------------------
# 0. 配置（按实际安装路径修改）
# -------------------------------------------------------
ASCEND_PATH=${ASCEND_PATH:-/usr/local/Ascend}
CANN_VERSION=${CANN_VERSION:-cann-8.5.0}
DEVICE_ID=${DEVICE_ID:-0}

CANN_HOME="${ASCEND_PATH}/${CANN_VERSION}"

echo "=========================================="
echo "  ASCEND_PATH  = ${ASCEND_PATH}"
echo "  CANN_VERSION = ${CANN_VERSION}"
echo "=========================================="

# -------------------------------------------------------
# 1. 加载 CANN 环境变量
# -------------------------------------------------------
if [ -f "${CANN_HOME}/set_env.sh" ]; then
    echo "[1/4] Sourcing CANN environment..."
    source "${CANN_HOME}/set_env.sh"
else
    echo "WARNING: ${CANN_HOME}/set_env.sh not found, skip sourcing."
fi

# -------------------------------------------------------
# 2. 检查必要工具
# -------------------------------------------------------
echo "[2/4] Checking tools..."

check_cmd() {
    if ! command -v "$1" &>/dev/null; then
        echo "ERROR: '$1' not found. Please install it."
        exit 1
    fi
    echo "  OK: $1 -> $(command -v $1)"
}

check_cmd cmake
check_cmd aarch64-linux-gnu-g++
check_cmd bisheng   # AscendC 专用编译器，随 CANN toolkit 安装

# -------------------------------------------------------
# 3. 构建
# -------------------------------------------------------
echo "[3/4] Building..."

BUILD_DIR="$(dirname "$0")/build"
mkdir -p "${BUILD_DIR}"
cd "${BUILD_DIR}"

cmake .. \
    -DCMAKE_BUILD_TYPE=Release \
    -DASCEND_PATH="${ASCEND_PATH}" \
    -DCANN_VERSION="${CANN_VERSION}"

make -j$(nproc) VERBOSE=1

echo "Build succeeded: ${BUILD_DIR}/matmul_demo"

# -------------------------------------------------------
# 4. 运行
# -------------------------------------------------------
echo "[4/4] Running matmul_demo on device ${DEVICE_ID}..."
cd "${BUILD_DIR}"
./matmul_demo

echo "Done."
