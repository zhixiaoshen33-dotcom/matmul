/**
 * main.cpp
 *
 * Host 端驱动程序：在昇腾 NPU 上执行 fp16 矩阵乘法 C = A * B
 *
 * 修复点：
 *  1. 矩阵维度改为 16 的整数倍（M=32, K=32, N=32），满足 Mmad 对齐要求
 *  2. host 端数据改为 uint16_t（fp16 的二进制表示），使用 fp32→fp16 转换函数
 *  3. 结果 C 以 float（fp32）接收并打印
 *  4. 补充了 aclrtSynchronizeDevice() 等待 kernel 执行完毕
 */

#include <iostream>
#include <vector>
#include <cmath>
#include <cstdint>
#include <acl/acl.h>

// -------------------------------------------------------
// ACL 错误检查宏
// -------------------------------------------------------
#define CHECK_ACL(cmd)                                          \
    do {                                                        \
        aclError _ret = (cmd);                                  \
        if (_ret != ACL_ERROR_NONE) {                           \
            std::cerr << "[ACL ERROR] " << #cmd                 \
                      << " failed, code=" << _ret               \
                      << " at " << __FILE__                     \
                      << ":" << __LINE__ << std::endl;          \
            exit(-1);                                           \
        }                                                       \
    } while (0)

// -------------------------------------------------------
// float32 <-> float16 转换工具函数
// IEEE 754 half-precision 转换，不依赖任何第三方库
// -------------------------------------------------------
static uint16_t float_to_fp16(float val)
{
    uint32_t bits;
    memcpy(&bits, &val, sizeof(bits));

    uint16_t sign     = (bits >> 16) & 0x8000;
    int32_t  exponent = ((bits >> 23) & 0xFF) - 127 + 15;
    uint32_t mantissa = bits & 0x7FFFFF;

    if (exponent <= 0) {
        return sign; // 下溢 → 0
    } else if (exponent >= 31) {
        return sign | 0x7C00; // 上溢 → inf
    }

    return sign | ((uint16_t)exponent << 10) | (uint16_t)(mantissa >> 13);
}

static float fp16_to_float(uint16_t val)
{
    uint32_t sign     = (val & 0x8000) << 16;
    uint32_t exponent = (val & 0x7C00) >> 10;
    uint32_t mantissa = (val & 0x03FF);

    uint32_t bits;
    if (exponent == 0) {
        bits = sign; // 非规格化 → 0
    } else if (exponent == 31) {
        bits = sign | 0x7F800000 | (mantissa << 13); // inf/nan
    } else {
        bits = sign | ((exponent + 127 - 15) << 23) | (mantissa << 13);
    }
    float result;
    memcpy(&result, &bits, sizeof(result));
    return result;
}

// -------------------------------------------------------
// kernel 声明（由 matmul_kernel.cpp 提供）
// -------------------------------------------------------
extern "C" void matmul_kernel_do(
    void* d_A, void* d_B, void* d_C,
    int M, int N, int K);

// -------------------------------------------------------
// 参考实现（CPU，用于验证结果）
// -------------------------------------------------------
static void ref_matmul(
    const std::vector<uint16_t>& A_fp16,
    const std::vector<uint16_t>& B_fp16,
    std::vector<float>&          C_ref,
    int M, int K, int N)
{
    C_ref.assign(M * N, 0.0f);
    for (int i = 0; i < M; ++i)
        for (int kk = 0; kk < K; ++kk) {
            float a = fp16_to_float(A_fp16[i * K + kk]);
            for (int j = 0; j < N; ++j) {
                float b = fp16_to_float(B_fp16[kk * N + j]);
                C_ref[i * N + j] += a * b;
            }
        }
}

int main()
{
    // -------------------------------------------------------
    // 1. 定义矩阵维度（必须为 16 的整数倍！）
    // -------------------------------------------------------
    const int M = 32;   // 行
    const int K = 32;   // 内维度
    const int N = 32;   // 列

    std::cout << "Matrix size: A(" << M << "x" << K
              << ") * B(" << K << "x" << N
              << ") = C(" << M << "x" << N << ")" << std::endl;

    // -------------------------------------------------------
    // 2. 生成 fp16 测试数据（A[i][k] = i+k+1, B[k][j] = 1）
    //    B 全 1 时，C[i][j] = sum_k A[i][k]，便于验证
    // -------------------------------------------------------
    std::vector<uint16_t> h_A(M * K), h_B(K * N);
    for (int i = 0; i < M; ++i)
        for (int k = 0; k < K; ++k)
            h_A[i * K + k] = float_to_fp16(float(i + k + 1));

    for (int k = 0; k < K; ++k)
        for (int j = 0; j < N; ++j)
            h_B[k * N + j] = float_to_fp16(1.0f);

    std::vector<float> h_C(M * N, 0.0f);

    // -------------------------------------------------------
    // 3. 初始化 Ascend runtime
    // -------------------------------------------------------
    CHECK_ACL(aclInit(nullptr));

    int deviceId = 0;
    CHECK_ACL(aclrtSetDevice(deviceId));

    aclrtContext context;
    CHECK_ACL(aclrtCreateContext(&context, deviceId));

    std::cout << "Ascend runtime initialized on device " << deviceId << std::endl;

    // -------------------------------------------------------
    // 4. 分配 Device 内存
    //    A, B 为 uint16_t（fp16），C 为 float（fp32）
    // -------------------------------------------------------
    void* d_A = nullptr;
    void* d_B = nullptr;
    void* d_C = nullptr;

    size_t sizeA = M * K * sizeof(uint16_t);
    size_t sizeB = K * N * sizeof(uint16_t);
    size_t sizeC = M * N * sizeof(float);

    CHECK_ACL(aclrtMalloc(&d_A, sizeA, ACL_MEM_MALLOC_HUGE_FIRST));
    CHECK_ACL(aclrtMalloc(&d_B, sizeB, ACL_MEM_MALLOC_HUGE_FIRST));
    CHECK_ACL(aclrtMalloc(&d_C, sizeC, ACL_MEM_MALLOC_HUGE_FIRST));

    // -------------------------------------------------------
    // 5. Host → Device 数据拷贝
    // -------------------------------------------------------
    CHECK_ACL(aclrtMemcpy(d_A, sizeA, h_A.data(), sizeA,
                          ACL_MEMCPY_HOST_TO_DEVICE));
    CHECK_ACL(aclrtMemcpy(d_B, sizeB, h_B.data(), sizeB,
                          ACL_MEMCPY_HOST_TO_DEVICE));

    std::cout << "Data transferred to device." << std::endl;

    // -------------------------------------------------------
    // 6. 调用 kernel
    // -------------------------------------------------------
    matmul_kernel_do(d_A, d_B, d_C, M, N, K);

    // 修复：等待 kernel 执行完毕，否则 Device→Host 拷贝可能读到无效数据
    CHECK_ACL(aclrtSynchronizeDevice());

    std::cout << "Kernel execution finished." << std::endl;

    // -------------------------------------------------------
    // 7. Device → Host 结果拷贝
    // -------------------------------------------------------
    CHECK_ACL(aclrtMemcpy(h_C.data(), sizeC, d_C, sizeC,
                          ACL_MEMCPY_DEVICE_TO_HOST));

    // -------------------------------------------------------
    // 8. 验证结果（与 CPU 参考实现对比）
    // -------------------------------------------------------
    std::vector<float> C_ref;
    ref_matmul(h_A, h_B, C_ref, M, K, N);

    float max_err = 0.0f;
    int   err_cnt = 0;
    for (int i = 0; i < M * N; ++i) {
        float err = std::fabs(h_C[i] - C_ref[i]);
        if (err > max_err) max_err = err;
        // fp16 计算允许约 0.5% 的相对误差
        if (err > std::fabs(C_ref[i]) * 0.01f + 1e-3f)
            ++err_cnt;
    }

    std::cout << "Max absolute error vs CPU reference: " << max_err << std::endl;
    if (err_cnt == 0) {
        std::cout << "[PASS] All elements match within tolerance." << std::endl;
    } else {
        std::cout << "[FAIL] " << err_cnt << " / " << M * N
                  << " elements exceed tolerance." << std::endl;
    }

    // -------------------------------------------------------
    // 9. 打印左上角 4x4 结果（避免大矩阵刷屏）
    // -------------------------------------------------------
    std::cout << "\nOutput C (top-left 4x4):" << std::endl;
    for (int i = 0; i < 4 && i < M; ++i) {
        for (int j = 0; j < 4 && j < N; ++j)
            std::cout << h_C[i * N + j] << "\t";
        std::cout << std::endl;
    }

    std::cout << "\nReference (top-left 4x4):" << std::endl;
    for (int i = 0; i < 4 && i < M; ++i) {
        for (int j = 0; j < 4 && j < N; ++j)
            std::cout << C_ref[i * N + j] << "\t";
        std::cout << std::endl;
    }

    // -------------------------------------------------------
    // 10. 释放资源
    // -------------------------------------------------------
    aclrtFree(d_A);
    aclrtFree(d_B);
    aclrtFree(d_C);
    aclrtDestroyContext(context);
    aclrtResetDevice(deviceId);
    aclFinalize();

    std::cout << "\nResources released. Done." << std::endl;
    return 0;
}
